/*
 *
 * Instituto Federal de Educação, Ciência e Tecnologia - IFPE
 * Curso: Informática para Internet
 * Disciplina: Lógica de Programação e Estrutura de Dados
 * Professor: Allan Lima - allan.lima@igarassu.ifpe.edu.br
 * 
 * Código de Domínio Público, sinta-se livre para usá-lo, modificá-lo e redistribuí-lo.
 *
 */
 
const express = require('express');
const session = require('express-session');
const host = 'localhost';
const porta = 3000;

var app = express();

app.use(session({ secret: 'XXassasas¨¨$', resave: false, saveUninitialized: true }));

app.use(express.static('public'));

app.set('views', (__dirname, 'views'));
app.set('view engine', 'pug');

app.get('/css/css.css', function(req, res, next){
	res.sendFile(__dirname + "/css/playervsplayer.css");
});
app.get('/css/menu.css', function(req, res, next){
    res.sendFile(__dirname + "/css/menu.css");
});

app.get('/', function(req, res, next) {
	
	res.write('<html lang="pt-br">');
	res.write('<head>');

	res.write('<embed src="songs/song1.mp3" hidden="true" loop="infinite" autostart="TRU">');
	res.write('<meta charset="UTF-8">');
	res.write('<title>Tic Tac Toe</title>');
	res.write('<link rel="stylesheet" href="css/menu.css" media="screen" charset="utf-8">');
	res.write('<link href="https://fonts.googleapis.com/css?family=Press+Start+2P" rel="stylesheet">');
	
	res.write('</head>');
	res.write('<body>');
	
	res.write('<h1>JOGO DA VELHA</h1><br>');
	res.write('<p>25 casas</p>');
	res.write('<h2><a href="/jogar" target="_self">JOGAR</a></h2><br>');
	res.write('<h2><a href="/instrucoes" target="_self">INSTRUÇÕES</a></h2><br>');
	res.write('<h2><a href="/sobre" target="_self">SOBRE O JOGO</a></h2><br>');
    
    res.write('</body>');
    res.write('</html>');
});

app.get('/jogar', function(req, res, next) {
	res.write('<html lang="pt-br">');
	res.write('<head>');

	res.write('<embed src="songs/song3.mp3" hidden="true" loop="infinite" autostart="TRU">');
	res.write('<meta charset="UTF-8">');
	res.write('<title>Tic Tac Toe</title>');
	res.write('<link rel="stylesheet" href="css/visualjogar.css" media="screen" charset="utf-8">');
	res.write('<link href="https://fonts.googleapis.com/css?family=Press+Start+2P" rel="stylesheet">');
	
	res.write('</head>');
	res.write('<body>');
	
	res.write('<h1>ESCOLHA UM MODO DE JOGO</h1>');
	res.write('<h2><a href="/playervsplayer">PLAYER VS PLAYER</a></h2><br>');
	res.write('<h2><a href="/" target="_self">VOLTAR</a></h2><br');
    
    res.write('</body>');
    res.write('</html>');

});

app.get('/instrucoes', function(req, res, next) {
    
    res.write('<html lang="pt-br">');
	res.write('<head>');

	res.write('<embed src="songs/song2.mp3" hidden="true" loop="infinite" autostart="TRU">');
	res.write('<meta charset="UTF-8">');
	res.write('<title>Tic Tac Toe</title>');
	res.write('<link rel="stylesheet" href="css/instrucoes.css" media="screen" charset="utf-8">');
	res.write('<link href="https://fonts.googleapis.com/css?family=Press+Start+2P" rel="stylesheet">');
	
	res.write('</head>');
	res.write('<body>');
	
	res.write('<h1>INSTRUÇÕES</h1>');
	res.write('<p>Dois jogadores escolhem entre X e O.</p>');
	res.write('<p>O objetivo é formar uma linha contendo 5 X ou 5 O, que podem ser na Vertical, Horizontal ou na Diagonal, e ao mesmo tempo impedir que o adversário forme uma linha.</p>');
	res.write('<p>Quando um jogador completa uma linha, geralmente os 5 X ou O são riscados.</p>');
	res.write('<p>Quando o jogo termina em empate, costuma-se dizer que deu velha.</p>');
	res.write('<h2><a href="/" target="_self">VOLTAR</a></h2><br');
    
    res.write('</body>');
    res.write('</html>');

});

app.get('/sobre', function(req, res, next) {
	
	res.write('<html lang="pt-br">');
	res.write('<head>');

	res.write('<embed src="songs/song4.mp3" hidden="true" loop="infinite" autostart="TRU">');
	res.write('<meta charset="UTF-8">');
	res.write('<title>Tic Tac Toe</title>');
	res.write('<link rel="stylesheet" href="css/sobre.css" media="screen" charset="utf-8">');
	res.write('<link href="https://fonts.googleapis.com/css?family=Press+Start+2P" rel="stylesheet">');
	
	res.write('</head>');
	res.write('<body>');
	
	res.write('<h1>SOBRE O JOGO</h1>');
	res.write('<p><br/>Criado e Desenvolvido por:<br/><br/> Joan Lucas, Email: joanlucaslopes@gmail.com<br/><br/> Jammilly Pereira, Email: pjammilly@gmail.com<br/><br/> Kauhan Rafael, Email: kauhanrafael@yahoo.com<br/><br/> Welyson de Lima, Email: well.lima.santana@gmail.com.<br/><br/>Jogo Da Velha Versão Alpha 0.2<br/></p>');
	res.write('<h2><a href="/" target="_self">VOLTAR</a></h2><br');
    
    res.write('</body>');
    res.write('</html>');

});

// entre em localhost:3000 para escrever os dados na sessao
app.get('/playervsplayer', function(req, res, next) {
	// se o array nao estiver na sessao, coloque-o na sessao
    res.render('index');
});

app.listen(3000, () => {
  console.log('Escutando localhost:3000');
})